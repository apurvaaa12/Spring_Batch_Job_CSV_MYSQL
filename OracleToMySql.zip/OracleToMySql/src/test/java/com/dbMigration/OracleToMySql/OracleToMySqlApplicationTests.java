//package com.dbMigration.OracleToMySql;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class OracleToMySqlApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
